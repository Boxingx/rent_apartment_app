package com.example.server_module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerModuleApplicationTests {

    @Test
    void contextLoads() {
    }

}
