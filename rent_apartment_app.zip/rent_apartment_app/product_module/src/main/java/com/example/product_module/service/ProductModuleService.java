package com.example.product_module.service;

public interface ProductModuleService {

    Double prepareProduct(Long id);

}
