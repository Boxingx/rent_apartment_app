package com.example.rent_module.model.dto;

import lombok.Data;

@Data
public class AddressDto {

    private String city;

    private String street;

    private String buildingNumber;

    private String apartmentsNumber;


}
