package com.example.rent_module.application_exceptions;

public class ApartmentException extends RuntimeException {

}
