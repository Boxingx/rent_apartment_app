package com.example.rent_module.model.dto;

import lombok.Data;

@Data
public class AuthDto {

    private String login;

    private String password;
}
