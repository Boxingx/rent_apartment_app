package com.example.rent_module.repository;



import com.example.rent_module.model.entity.ProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<ProductEntity, Long> {
    ProductEntity getProductEntityByProductName(String name);
}
