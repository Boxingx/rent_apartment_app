package com.example.rent_module.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RentApartmentException {

    private String exceptionCode;

    private String exceptionMessage;

}
