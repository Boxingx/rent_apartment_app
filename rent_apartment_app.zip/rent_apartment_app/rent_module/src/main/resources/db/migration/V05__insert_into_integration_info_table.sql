INSERT INTO integration_info
VALUES
(2, 'X-Yandex-API-Key', 'yandex_weather', '78896c16-2a25-4d1a-bb9a-6426464db648', 'https://api.weather.yandex.ru/v2/forecast?lat=%s&lon=%s&lang=ru_RU')