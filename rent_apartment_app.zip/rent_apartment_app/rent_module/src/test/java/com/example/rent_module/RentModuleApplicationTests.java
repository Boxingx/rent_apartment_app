package com.example.rent_module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentModuleApplicationTests {

    @Test
    void contextLoads() {
    }

}
