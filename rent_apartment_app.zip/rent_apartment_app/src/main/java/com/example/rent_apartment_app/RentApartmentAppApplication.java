package com.example.rent_apartment_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentApartmentAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(RentApartmentAppApplication.class, args);
    }

}
